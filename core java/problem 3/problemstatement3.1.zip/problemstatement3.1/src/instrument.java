
public abstract class instrument {


	public void Play() {
		// TODO Auto-generated method stub
		
	}
}
