import java.util.Scanner;

public class TestRectangle {
	public static int length;
	public static int breadth;
	public static int area;

public static void main(String[] args) {
	TestRectangle rec= new TestRectangle();
	Scanner scan=new Scanner(System.in);
	System.out.println("enter length and breadth for rectangle 1: ");
	rec.length=scan.nextInt();
	rec.breadth=scan.nextInt();
	rec.area= length * breadth;
	System.out.println("area of rectangle 1: "+ rec.area);
	//2nd rectangle
	
	TestRectangle rec1= new TestRectangle();
	System.out.println("enter length and breadth for rectangle 2: ");
	rec1.length=scan.nextInt();
	rec1.breadth=scan.nextInt();
	rec1.area= length * breadth;
	System.out.println("area of rectangle 2: "+ rec1.area);
	
	//3rd
	TestRectangle rec3= new TestRectangle();
	System.out.println("enter length and breadth for rectangle 3: ");
	rec3.length=scan.nextInt();
	rec3.breadth=scan.nextInt();
	rec3.area= length * breadth;
	System.out.println("area of rectangle 3: "+ rec3.area);
	
	//4
	TestRectangle rec4= new TestRectangle();
	System.out.println("enter length and breadth for rectangle 4: ");
	rec4.length=scan.nextInt();
	rec4.breadth=scan.nextInt();
	rec4.area= length * breadth;
	System.out.println("area of rectangle 4: "+ rec4.area);
	
	//5
	TestRectangle rec5= new TestRectangle();
	System.out.println("enter length and breadth for rectangle 5: ");
	rec5.length=scan.nextInt();
	rec5.breadth=scan.nextInt();
	rec5.area= length * breadth;
	System.out.println("area of rectangle 5: "+ rec5.area);
}
}
