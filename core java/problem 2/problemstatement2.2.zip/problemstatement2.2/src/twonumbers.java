
public class twonumbers {
	  public static void main(String[] args) {

		    int x = 1, n = 13, firstnum = 0, secondnum = 1;
		    System.out.println("Fibonacci Series till " + n + " terms:");

		    while (x <= n) {
		      System.out.print(firstnum + ", ");

		      int nextnum = firstnum + secondnum;
		      firstnum = secondnum;
		      secondnum = nextnum;

		      x++;
		    }
		  }
}
