import java.util.ArrayList;

public class Studentlist {
public static void main(String args[]){  
	     ArrayList<String> list=new ArrayList<String>();  
	      list.add("Alexa");
	      list.add("Siri");
	      list.add("booty");
	      
	      if (list.contains("Alexa"))
	            System.out.println("Alexa exists in the ArrayList");
	      else
	            System.out.println("Alexa does not exist in the ArrayList");
	      
	      if (list.contains("tommy"))
	            System.out.println("Tommy exists in the ArrayList");
	      else
	            System.out.println("Tommy does not exist in the ArrayList");
	}
}
