import java.util.Hashtable;
import java.util.Scanner;
public class Hashproduct 
{	
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	Hashtable<String,String> hash=new Hashtable<String,String>();
	System.out.println("enter the product id and name;");
	for(int i=0;i<3;i++)
		{
			hash.put(scan.next(),scan.next());
		}
	System.out.println("the product list is:");
	System.out.println(hash);
	System.out.println("enter the product id to be removed:");
	String id = scan.next();
	hash.remove(id);
	System.out.println("item removed");
	System.out.println("the product list is:");
	System.out.println(hash.toString());
	System.out.println("enter the product id to be searched:");
	String sid=scan.next();
	 if(hash.containsKey(sid))
		{
			System.out.println(hash.get(sid));
		}
		else {
			System.out.println("do not exist");
		}
	} 
}


