import java.util.Scanner;

public class Phonebook {
	static String temp;
	public static String help_msg=	"Press:   -  a  Add new phone book entry   -  b  Search Phone Number  - c  Exit :";
	public static void main(String[] args) {		
		System.out.println("\n\n nPhone Book \n\n");
		Scanner s=new Scanner(System.in);		
		for(;;){
				System.out.print("[Main Menu] "+help_msg+"\n:");
				String command=s.nextLine().trim();				
 
				if (command.equalsIgnoreCase("a")){
					System.out.print("Type in contact details in the format: name,lastname,phone\n:");
					System.out.println("enter details: ");
					temp=s.nextLine();
					
 
				}else if (command.equalsIgnoreCase("b")){
					System.out.print("Type in the name you are searching for :\n:");
					System.out.println(temp);
 
				}else if (command.equalsIgnoreCase("c")){
					System.out.println("Exit User...");
					System.exit(0);
				}else{					
					System.out.print(" Try again \n:");
				}
 
		}
 
	}
}
