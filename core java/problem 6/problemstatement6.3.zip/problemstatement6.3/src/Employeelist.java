import java.util.LinkedList;

public class Employeelist {
private static final Employee[] v = null;

	public static void main(String[] args) {
		LinkedList<Employee> v = addInput();
		display(v);
	}

	private static LinkedList<Employee> addInput() {
		Employee e1 = new Employee(120, "Namratha","Banglore");
		Employee e2 = new Employee(121, "Ameya", "Pune");
		Employee e3 = new Employee(122, "Kabir", "Mumbai");
		LinkedList<Employee> v = new LinkedList<Employee>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	}

	private static void display(LinkedList<Employee> v) {
		for (Employee e : v) {
			System.out.println(e.getEmpid() + "\t" + e.getEname() + "\t" + e.getAddress());
		}
	}

}
