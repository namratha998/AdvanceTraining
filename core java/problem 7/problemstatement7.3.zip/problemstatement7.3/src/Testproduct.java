import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Scanner;

public class Testproduct {
public static void main(String[] args) {
		
		writeData();	

		}
		
		public static void writeData() {
			
			HashSet<Product> setOfStrs = new HashSet<>();
			
			System.out.println("Enter Number of Entries: ");
			Scanner input = new Scanner(System.in);
			int n = input.nextInt();
			
			
			
			for(int i=1;i<=n;i++) {
				
				System.out.println("Enter ProductId: ");
				int id = input.nextInt();
				input.nextLine();
				
				System.out.println("Enter ProductName: ");
				String name = input.next();
				
				Product p1 = new Product(id,name);
				
				setOfStrs.add(p1);
				
			}
			
			
			
			
			try {
			      FileWriter myWriter = new FileWriter("filename.txt");
			      for (Product val : setOfStrs) {
			    	  myWriter.write("Product Id: "+val.getProduct_Id()+" "+"Product Name: "+val.getProdct_Name());
			    	  myWriter.write("\n");
			      }
			      myWriter.close();
			      System.out.println("Successfully wrote to the file.");
			    } catch (IOException e) {
			      System.out.println("An error occurred.");
			      e.printStackTrace();
			    }
			
		}
		

}
