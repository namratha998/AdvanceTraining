package problems;

public class sortedArray {
	static void printFrequency(int arr[], int n)
	  {
	      int frequency = 1;
	    for (int i = 1; i < n; i++) {
	            if (arr[i] == arr[i - 1]) {
	               frequency++;
	          }
	     else {
	             System.out.println(arr[i - 1]+" occurs "+frequency + " times ");
	               frequency = 1;
	            }
	      }
	 
	      System.out.println( arr[n - 1]+" occurs "+frequency+ " times " );
	    }
	 
public static void main(String args[])
	  {
	     int arr[]= { 1, 1, 1, 2, 3, 3, 5, 5, 8, 8, 8, 9, 9, 10 };
	  // int arr[]= {2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9};
	    int n = arr.length;
	      printFrequency(arr, n);
	    }
}
