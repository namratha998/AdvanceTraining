package problems;

import java.util.HashSet;
import java.util.Scanner;

public class RepeatingArray {
	 static void printFirstRepeating(int array[])
	    {
	        int mini = -1;
	 
	        HashSet<Integer> set = new HashSet<>();
	        for (int i=array.length-1; i>=0; i--)
	        {
	        	
	            if (set.contains(array[i]))
	                mini = i;
	            else 
	                set.add(array[i]);
	        }
	        if (mini != -1)
	          System.out.println("The first repeating element is " + array[mini]);
	        else
	          System.out.println("There are no repeating elements");
	    }
	    public static void main (String[] args) throws java.lang.Exception
	    {
	    	 Scanner sc = new Scanner(System.in);
	    	 System.out.println("enter length of array : ");
	    	int[] arr = new int[sc.nextInt()];
	        System.out.println("enter array values : ");
	        for (int i = 0; i < arr.length; i++) {
	            arr[i] = sc.nextInt();
	         }
	        printFirstRepeating(arr);
	    }
}
